
def consonant_count(string):
    vowels = 'aeiou'
    count = 0
    for char in string.lower():
        if