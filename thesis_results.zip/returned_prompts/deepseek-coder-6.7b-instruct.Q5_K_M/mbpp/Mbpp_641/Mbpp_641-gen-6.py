"""
To find the nth nonagonal number, you can use the formula for the nth nonagonal number, which is n*(7*n-5)/2.
"""

