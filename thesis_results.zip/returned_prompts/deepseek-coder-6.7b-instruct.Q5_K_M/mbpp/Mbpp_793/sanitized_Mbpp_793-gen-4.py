def last(lst, element):
    if element in lst:
        return lst.index(element)
    else:
        return -1