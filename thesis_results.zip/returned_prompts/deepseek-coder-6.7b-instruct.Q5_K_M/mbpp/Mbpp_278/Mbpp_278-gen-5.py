
def min_element(tuples):
    return min(tuples)

print(min_element((1, 