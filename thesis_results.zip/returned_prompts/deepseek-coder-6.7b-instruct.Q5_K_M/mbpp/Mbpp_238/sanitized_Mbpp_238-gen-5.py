def number_of_substrings(s: str):
    n = len(s)
    return n * (n + 1) // 2