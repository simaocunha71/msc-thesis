def number_of_substrings(s):
    length = len(s)
    return (length * (length + 1)) // 2