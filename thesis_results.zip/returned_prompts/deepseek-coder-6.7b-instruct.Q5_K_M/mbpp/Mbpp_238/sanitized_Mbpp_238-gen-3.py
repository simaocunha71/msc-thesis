def number_of_substrings(s):
    n = len(s)
    return n * (n + 1) // 2