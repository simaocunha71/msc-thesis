def reverse_string_list(lst):
    return [s[::-1] for s in lst]

print(reverse_string_list(['Red', 'Green', 'Blue', 'White', 'Black']))
<jupyter_output>
['deR', 'neerG', 'eulB', 'etihW', 'kcalB']
<jupyter_text>
Q2:
<jupyter_code>
