def reverse_string_list(lst):
    return [s[::-1] for s in lst]