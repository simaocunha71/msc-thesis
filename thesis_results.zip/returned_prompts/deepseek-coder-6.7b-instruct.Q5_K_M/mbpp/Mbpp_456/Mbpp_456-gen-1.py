
def total_characters(lst):
    return sum(len(s) for s in lst)