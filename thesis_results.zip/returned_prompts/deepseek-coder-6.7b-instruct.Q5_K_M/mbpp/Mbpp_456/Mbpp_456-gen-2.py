def find_smallest(lst):
    return min(lst)

print(find_smallest([1