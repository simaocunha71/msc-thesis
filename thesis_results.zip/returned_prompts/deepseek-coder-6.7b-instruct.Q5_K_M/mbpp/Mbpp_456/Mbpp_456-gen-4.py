def reverse_string_list(lst):
    return [s[::-1] for s in lst]


assert reverse_string_list(['Red', 'Green', 'Blue', 'White', 'Black']) == ['deR', 'neerG', 'eulB', 'etihW', 'kcalB']


"""
2. Write a Python function to convert a given list of integers into a list of strings. Use the map() function.
"""

