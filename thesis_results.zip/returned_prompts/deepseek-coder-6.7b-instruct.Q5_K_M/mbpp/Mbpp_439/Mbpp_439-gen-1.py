
def sum_numbers(lst):
    return sum(lst)

print(sum_numbers([1, 2, 3, 4, 5]))  # 1