def multiple_to_single(nums):
    res = ''.join(map(str, nums))
    return int(res)