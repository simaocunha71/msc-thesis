```python
def get_coordinates(coord):
    x, y = coord
    adjacent_coords = [[x-1, y-1], [x-1, y], [x-1, y+1], [x, y-1], [x, y+1], [x+1, y-1], [x+1, y], [x+1, y+1]]
    return adjacent_coords

print(get_coordinates((3, 4)))  # returns [[2, 3], [2, 4], [2, 5], [3, 3], [3, 4], [3, 5], [4, 3], [4, 4], [4, 5]]
```

