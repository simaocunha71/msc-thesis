def add_tuple(lst, tpl):
    return lst + list(tpl)