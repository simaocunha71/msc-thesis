```python
def add_tuple(lst, tup):
    return lst + list(tup)

print(add_tuple([5, 6, 7], (9, 10)))  # [5, 6, 7, 9, 10]
```

