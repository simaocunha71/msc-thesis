```python
def add_tuple(lst, tup):
    lst.extend(tup)
    return lst
```

