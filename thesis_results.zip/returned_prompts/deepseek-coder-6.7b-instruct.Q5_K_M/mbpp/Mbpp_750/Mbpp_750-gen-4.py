def add_tuple(lst, tpl):
    return lst + list(tpl)

print(add_tuple([5, 6, 7], (9, 10)))

#or

def add_tuple(lst, tpl):
    return lst + list(tpl)

print(add_tuple([5, 6, 7], (9, 10)))

#or

def add_tuple(lst, tpl):
    return lst + list(tpl)

print(add_tuple([5, 6, 7], (9, 10)))

#or

def add_tuple(lst, tpl):
    return lst + list(tpl)

print(add_tuple([5, 6, 7], (9, 10)))

#or

def add_tuple(lst, tpl):
    return lst + list(tpl)

print(add_tuple([5, 6, 7], (9, 10)))
<jupyter_output>
[5, 6, 7, 9, 10]
<jupyter_text>
