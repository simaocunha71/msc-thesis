def add_tuple(lst, tup):
    return lst + list(tup)