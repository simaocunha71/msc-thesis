def toggle_string(s):
    return s.swapcase()

# Test
print(toggle_string("Python"))  # Should return "pYTHON"


