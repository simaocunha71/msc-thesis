def toggle_string(s):
    return s.swapcase()

print(toggle_string("Python"))

# Output: pYTHON


