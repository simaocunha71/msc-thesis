def toggle_string(s):
    return s.swapcase()