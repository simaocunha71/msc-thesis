def issort_list(l):
    return l == sorted(l)