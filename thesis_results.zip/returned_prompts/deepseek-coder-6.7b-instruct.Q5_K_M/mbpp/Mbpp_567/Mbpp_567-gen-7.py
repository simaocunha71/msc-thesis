def issort_list(l):
    return l == sorted(l)

print(issort_list([1,2,4,6,8,10,12,14,16,17])) # False


