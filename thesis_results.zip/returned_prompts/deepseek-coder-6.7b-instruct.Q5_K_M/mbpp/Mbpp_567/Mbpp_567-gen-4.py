def issort_list(lst):
    return lst == sorted(lst)

print(issort_list([1,2,4,6,8,10,12,14,16,17]))

