def list_union(a, b):
    return list(set(a) | set(b))

print(