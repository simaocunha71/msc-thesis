def issort_list(lst):
    return lst == sorted(lst)