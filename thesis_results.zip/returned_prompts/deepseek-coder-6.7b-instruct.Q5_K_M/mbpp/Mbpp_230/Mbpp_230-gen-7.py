def replace_blank(s, c):
    return s.replace(' ', c)

print(replace_blank("hello people",'@'))
<jupyter_output>
hello@people
<jupyter_text>
Problem 2:
<jupyter_code>
