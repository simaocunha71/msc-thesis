
def replace_blank(string,character):
    return string.replace(' ',character)

print(replace_blank("hello people",'@'))

"""
Output:
"hello@people"
"""

