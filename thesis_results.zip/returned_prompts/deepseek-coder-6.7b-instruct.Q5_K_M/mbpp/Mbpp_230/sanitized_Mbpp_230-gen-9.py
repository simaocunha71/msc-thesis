def replace_blank(s, c):
    return s.replace(" ", c)