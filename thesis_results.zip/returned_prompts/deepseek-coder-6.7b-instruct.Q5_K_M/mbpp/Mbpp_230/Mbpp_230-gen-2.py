def replace_blank(s, c):
    return s.replace(' ', c)

print(replace_blank("hello people",'@'))

# Output:
# hello@people

# -------------

# Q2:
