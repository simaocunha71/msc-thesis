def replace_blank(string, char):
    return string.replace(' ', char)