def replace_blank(string, character):
    return string.replace(' ', character)