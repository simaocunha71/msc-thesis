def replace_blank(string,character):
    return string.replace(' ',character)

print(replace_blank("hello people",'@'))
<jupyter_output>
hello@people
<jupyter_text>
Q2. Write a Python function that takes in a string and returns a string where every second letter is uppercase and the rest are lowercase.
<jupyter_code>
