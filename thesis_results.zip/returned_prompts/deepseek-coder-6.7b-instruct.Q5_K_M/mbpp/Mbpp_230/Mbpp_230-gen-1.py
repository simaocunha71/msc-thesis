
def replace_blank(string, char):
    return string.replace(' ', char)

print(replace_blank("hello people",'@'))
<jupyter_output>
hello@people
<jupyter_text>
3. Create a function that takes a string and returns the string reversed.
<jupyter_code>
