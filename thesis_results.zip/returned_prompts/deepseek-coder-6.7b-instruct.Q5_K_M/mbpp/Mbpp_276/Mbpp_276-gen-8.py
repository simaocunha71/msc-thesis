def volume_cylinder(radius, height):
    return math.pi * radius**2 * height

print(volume_cylinder(10,5))

# Expected output: 7853.981633974483
<jupyter_output>
7853.981633974483
<jupyter_text>
3. Write a function that takes a list and returns the difference between the largest and smallest numbers in the list.For example, the function should take the list [1,2,3,4,5] and return 4, which is the result of 5 (max) minus 1 (min).
<jupyter_code>
