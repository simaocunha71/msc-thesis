def volume_cylinder(radius, height):
    return math.pi * radius**2 * height

print(math.isclose(volume_cylinder(10,5), 1570.7500000000002, rel_tol=0.001))
<jupyter_output>
True
<jupyter_text>
Question 4
<jupyter_code>
