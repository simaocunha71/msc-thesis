"""
Here is a simple python function that calculates the volume of a cylinder.

def volume_cylinder(radius, height):
    return math.pi * radius**2 * height

print(volume_cylinder(10,5))
"""

