def volume_cylinder(radius, height):
    return 3.14159 * radius**2 * height