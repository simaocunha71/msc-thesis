def find_substring(lst, s):
    return any(s in i for i in lst)