"""
Here is the python code for the problem:

def newman_prime(n):
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]
    return primes[n-1]

print(newman_prime(3)) # 7
"""

