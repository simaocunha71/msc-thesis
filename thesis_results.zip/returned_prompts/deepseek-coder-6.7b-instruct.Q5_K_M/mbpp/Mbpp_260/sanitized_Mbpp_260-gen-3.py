def newman_prime(n: int) -> int:
    return 2**n + 2**(2**n) + 1