"""
def text_starta_endb(text):
    pattern = re.compile("a.*b$")
    if re.search(pattern, text):
        return True
    else:
        return False
"""
