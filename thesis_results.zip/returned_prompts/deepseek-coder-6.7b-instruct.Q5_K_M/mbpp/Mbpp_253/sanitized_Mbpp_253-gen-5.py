def count_integer(lst):
    return sum(1 for i in lst if isinstance(i, int))