def count_integer(lst):
    return len([i for i in lst if type(i) == int])