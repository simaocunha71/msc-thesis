
def min_integer(l