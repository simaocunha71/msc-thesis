import math
import math
import math
def is_perfect_square(n):
    return n == (int(n**0.5))**2