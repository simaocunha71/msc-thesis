def is_perfect_square(n):
    return int(n ** 0.5) ** 2 == n

assert not is_perfect_square(10)
"""

