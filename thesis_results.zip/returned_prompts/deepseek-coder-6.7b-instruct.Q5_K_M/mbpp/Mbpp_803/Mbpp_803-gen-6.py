
```python
def is_perfect_square(num):
    return num == (int(num ** 0.5)) ** 2

assert not is_perfect_square(10)
```

