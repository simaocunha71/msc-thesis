def is_palindrome_str(s):
    return