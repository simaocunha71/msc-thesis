def sort_numeric_strings(lst):
    return sorted(int(num) for num in lst)