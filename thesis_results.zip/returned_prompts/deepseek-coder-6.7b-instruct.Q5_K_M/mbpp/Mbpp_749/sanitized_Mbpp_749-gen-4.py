def sort_numeric_strings(lst):
    return sorted(map(int, lst))