def sort_numeric_strings(lst):
    return sorted(int(i) for i in lst)